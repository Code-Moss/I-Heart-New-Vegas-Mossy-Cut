MAXIMUM NEW VEGAS Mod Config
--------------------
\\\\\\\\\\\\\\\\\\\\
--------------------

I N S T A L L S :
(Descriptions outdated)

--------------------

• Desert Natural Weathers Custom INI...

	> Slightly Boosted Saturation.
	> Slightly Boosted Night Brighness.
	
--------------------

• Enhanced Camera Custom INI...

	> Disabled Most First person animations.
	> Enabled First Person Death animations.
	> Enabled First Person VATS (Sometimes doesn't work).
	
--------------------

• FOV Slider Custom INI...

	> Slightly Reduced Player FOV.
	> Increased Player World FOV.
	
--------------------

• JIP CCC Custom INI...

	> Changed interface to Light.
	> Set custom Controls to be compatable with lStewieAl's Tweaks (Scrollable Hotkeys).
	
--------------------

• JIP LN NVSE Plugin Custom INI...

	> Too many to list, check the INI.
	
--------------------

• JSawyer Ultimate Custom INI...

	> Too many to list, check the INI.
	
--------------------	

• Just Mods Assorted Custom INI...
	
	> Too many to list, check the INI.
	
--------------------

• lStewieAl's Tweaks and Engine Fixes Custom INI...

	> Way, WAY too many to list, check the INI.
	
--------------------

• Mojave Arsenal Custom INI...

	> Added Weapon Mods to loot.
	> Added abillity to craft Pulse Slugs.
	
--------------------

• NVTF Custom INI...

	> Custom Fixes and Performance improvements.
	
--------------------

• RAD Custom INI...
	
	> Enabled Hardcore and JSawyer Increments.
	
--------------------

• Ragdolls Custom INI...

	> Decreased melee damage ragdoll strength.
	
--------------------
	
• Vanilla UI Plus (New Vegas) Custom INI...

	> Decreased Dialogue Choice sizes and added Numbered Options.
	
--------------------
	
• yUI - User Ynterface Custom INI...

	> Matched cursor to HUD color.
	
--------------------
\\\\\\\\\\\\\\\\\\\\
--------------------
--------------------