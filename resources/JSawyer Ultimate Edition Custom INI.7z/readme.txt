JSawyer Utlimate Edition: Push's Tweaks
by PushTheWinButton
(https://forums.nexusmods.com/index.php?/user/13822205-pushthewinbutton/)
____________________________________________________________________________________________________

NB: SOME DETAILS CHANGED BY MOSS...

This is a collection of my personal tweaks that I think make the game more balanced/hard. These are partly inspired by the more difficult state of the game when it launched, prior to official patches, especially when it comes to crafting. I'd include these in the main file, except they go slightly beyond the scope and could definitely be controversial.

I've included by INI config, which contains a few minimal changes described below. The section following this details the changes in the plugin.
____________________________________________________________________________________________________
[=======================]
[=====[INI CHANGES]=====]
[=======================]

ARMOR:bVanillaPowerArmor=1

REASONING: I don't like Sawyer's changes to power armour. Most power armours have a STR bonus, meaning they already increase carry weight by +10 per extra point of STR. The additional +20 carry weight from having the Power Armor Training perk effectively makes most power armours near weightless, so altogether it's quite overpowered.

ITEMS:bSpecialNukaLoot=1

REASONING: Nuka Quartz and Victory (and Quantum) are very scarce and limited in the vanilla game (without Nuka Chemist), despite being used in some recipes (Atomic Cocktail and Nuka Grenade). With this option enabled, the items are still rare, but there's now more oppertunity to obtain them, and the recipes are slighty more viable.

ITEMS:bSuperStimpakNameChange=1

REASONING: This one is self-explanatory—I like the names to match.

ITEMS:iPurifiedWaterReplaceChance=75

REASONING: This gives a 75% chance that any Dirty Water items placed in the world will be replaced with Purified Water. Helps make Purified Water rarer and incentivises the use of Cactus Water and Mass Purified Water recipes.

ITEMS:fChanceBobbyPins=20

REASONING: Bobby Pins are never in short supply. This setting probably doesn't go far enough.

ITEMS:fChanceMagazines=20

REASONING: Magazines are more commonly found placed in the world, and there's a lot of them. There's no need for much extra, so this cuts their occurance in loot.

STATS:bExpandedKarmaEdits=1

REASONING: This option makes additional karma changes, partly inspired by Fallout 3. In the vanilla game, most NPCs are set to Neutral karma, clearly because no-one bothered to balance the karma system. A large number of innocent NPCs have their karma shifted from Neutral to Good, so that you get negative karma if you kill them. In the vanilla game, Brotherhood members are split between Neutral and Good, with no consistency at all. This option changes them all to Neutral to prevent karma loss from killing them. Finally, some raiders and criminals (e.g. Freeside Thugs and Omertas) have been moved from Neutral to Evil, to match other raider-type enemies in the vanilla game.
____________________________________________________________________________________________________
[==========================]
[=====[PLUGIN CHANGES]=====]
[==========================]

* Stimpak: value decreased from 75 to 25. (This was the value when the game launched.)
* Auto-Inject Stimpak: value decreased from 75 to 25.
* Super Stimpak: value decreased from 150 to 100. (This was the value when the game launched.)
* Auto-Inject Super Stimpak: value decreased from 150 to 100.
* Stimpak, Homemade: value decreased from 50 to 15.
* Stimpak, Expired: value decreased from 35 to 10.

REASONING: At 75 caps, Stimpaks were very high-value considering how common and low-weight they were. Whilst it is true that the value of 25 caps may have originally been carried over from Fallout 3, I believe that this lower value is still more balanced. It also makes Medicine more balanced against Survival, as Stimpaks can more easily be pruchased if the player encounters a shortage. Interestingly, Stimpaks and Super Stimpaks are already valued at 25 and 100 caps at the Sierra Madre Vending Machines, which makes sense since the value was changed during the development of Dead Money and it appears the vending recipes weren't updated.
	
* Weapon Repair Kit: increased the amount of Scrap Metal required from 2 to 3; increased the number of Wrenches and Wonderglue required from 1 to 2. Breakdown recipes are also affected. (This is how the recipe was when the game launched.)
* Armour Repair Kit: increased the number of Leather Belts, Wonderglue, and Duct Tape required from 1 to 2. Breakdown recipes are also affected.

REASONING: Repair kits were too easy to craft in the vanilla (patched) game, and the incentive to craft them lead to hording of the necassary components and surplus repair kits. This devalued the usual repair route, merchant repair services, and the Jury Rigging perk.

* Increased weapon degradation rate by 50%.

REASONING: Weapons degrade at a much slower rate in New Vegas compared to Fallout 3, despite there also being less combat for large stretches of the game. This change aims to get more use out of the repair system.

* Dog Steak: replaced with Dog Stew, and changed the model and icon to match; now requires Purified Water, Pinto Bean Pod, and Fresh Carrot to craft; recipe produces 2 stews; added -30 H2O.
* Coyote Steak: replaced with Dog Stew, and changed the model and icon to match; now requires Purified Water, Pinto Bean Pod, and Fresh Carrot to craft; recipe produces 2 stews; added -30 H2O.
* Gecko Steak: reverted changes to the health and FOD restoration from the base mod; now requires Buffalo Gourd Seed to craft. (Homage to the Gecko Kebab, which originally required Buffalo Gourd Seeds when the game launched.)
* Gecko Kebab: increased Banana Yucca Fruit crafting requirement from 1 to 2. 
* Gecko Meat: reverted changes to FOD restoration from the base mod.
* Grilled Mantis Leg: now requires 2 Honey Mequite Pod to craft.
* Fire Ant Fricassee: now requires 2 Brahmin Meat to craft.
* Mushroom Cloud: now requires 2 Nightstalker Eggs.
* Trail Mix: now requires 2 Pinyon Nuts.
* Desert Salad: now requires 2 Barrel Cactus Fruit and 2 Pinyon Nuts to craft.
* Brahmin Steak: now requires Wine to craft and 2 meat to craft; recipe produces 2 steaks.
* Bighorner Steak: now requires Wine to craft and 2 meat to craft; recipe produces 2 steaks.
* Cook-Cook's Fiend Stew: now requires 2 Brahmin Meat to craft.
* Ruby Nash now requires 3 Radscorpion Poison Glands, and will bake 2 Spicy Casseroles. After the first time you use this option, she won't bake any more, but will instead give you a (previously cut) recipe so you can make them yourself.

REASONING: Perhaps my most controversial changes, but much needed. The Brahmin Steak recipe originally required Wine (1) and Brahmin Meat (2) to craft two steaks when the game launched, which explains why the steak has a STR bonus in the vanilla game. For this reason, it is likely that Bighorner Steak also required Wine at some point, hence the STR bonus. I've re-added this requirement to both recipes. Altogether, the changes to steaks make them harder to craft, as the secondary requirements act as a limiting factor. The prevalence of animal meat, simplicity of steak recipes, and their high health restoration utterly devalued the survival aspect of the vanilla game in my opinion. Now playing as a Survival character will require you to collect more ingredients, buy more food, and you might have to use a Stimpak occassionally (as you should—this is a Fallout game after all and stimpaks SHOULD be your primary healing item). Other food items become more important too. When was the last time you actually ate Blamco Mac and Cheese, if ever?

* Decreased the amount of items harvested from Prickly Pear Cactus, Jalapeno, and Pinto plants from 2 to 1.

REASONING: Even with the changes to Cactus Water below, the recipe was still too easy to craft due to the abundance of Prickly Pear Cactus plants and each one giving two fruit. The other two plants are rarely used in crafting, so getting two items per harvest meant that you would always have a surplus. Jalapenos are common, but Pinto plants only grow in two wilderness ares. However, there's an abundant supply of all plants at the Sharecropper Farms.

* Antivenom: increase Radscorpion Poison Gland requirement from 2 to 4. (This is how the recipe was when the game launched.)
* Datura Antivenom: increased Sacred Datura Root requirement from 1 to 2.
* Snakebite Tourniquet: now requires Antivenom to craft.

REASONING: The Snakebite Tourniquet change is obvious—in the vanilla game, it has the same effect as Antivenom, but only requires one measly Buffalo Gourd Seed (a common flora in the wasteland) and some useless tubing. The changes to antivenom make it harder to mass produce, especially considering how common Radscorpion Poison Glands are in some locations. The Antivenom recipes produces two items, by the way, whereas the Datura Antivenom only produces one.

* Hydra: increased recipe Radscorpion Poison Gland requirement from 1 to 2; increased Cave Fungus requirement from 1 to 2.

REASONING: Hydra is the most potent limb restoration item in the game, so this makes it slightly more difficult to craft.

* Cactus Water: increased number of Prickly Pear Fruit required from 2 to 3. (This is how the recipe was when the game launched.)

REASONING: This makes Cactus Water harder to craft, making Purified Water slightly harder to obtain as it means you need to harvest more than one Prickly Pear Cactus plant. This plays nicely with other changes to Purified Water rarity.

* Mass Purified Water: now also requires a Pressure Cooker to craft.

REASONING: This is more logicial (distillation), more closely resembles the recipe at launch, and means you will need to lug extra weight around if you want easy access to Purified Water.

* Decreased the amount of Purified Water in Legion footlockers.

REASONING: Another change affecting the rarity of Purified Water. The loot list used by Legion footlockers contained three entries for Purified Water, at counts of 1, 2, and 3. One or these has been replaced with Dirty Water, and all three have been changed to a count of 1.

* Healing Poultice: replaced Broc Flower and Xander Root crafting requirements with 1 Healing Powder; increased Cave Fungus crafting requirement from 1 to 2.

REASONING: This prevents you hording Broc and Xander whilst waiting to find the other ingredients. Now the recipes essentially 'upgrades' the standard Healing Powder.

* Satchel Charge: increased Lead and Pistol Powder requirements from 25 to 250.

REASONING: In the vanilla game, satchel charges only required the gunpowder-equivalent of a few bullets, whereas they do more damage than a Bottlecap Mine, which is far harder to craft. This change makes Satchel Charges a much more costly option.

* Powder Charge: replaced 2 Dynamite crafting requirement with 50 Pistol Powder.

REASONING: Now matches the Tin Grenade crafting ingredients and makes them much easier to craft. I also disabled the GRA "Efficient" recipe for this item, as those recipes are stupid overall (and I wanted to maintain compatability with Mojave Arsenal).

* Removed some extra Empty Syringe leveled lists from containers.

REASONING: Extra syringes were added to first aid kits, vendor lists, and Fiend loot in one of the official patches in response to feeback that they were to rare. However, their addition to first aid kits makes them too common in my opinion. There are plenty of Empty Syringes in loot lists, for sale, and placed in the world.

* Added Lunchbox to LL0NPCBaseTrinkets, LL0NPCTownTrinkets, LL0NPCWastelandTrinkets and LL0NPCPowderGangerTrinkets leveled lists (in higher proportion for the Powder Ganger leveled lists).
* Added Cherry Bomb to LL0NPCTownTrinkets, LL0NPCWastelandTrinkets and LL0NPCPowderGangerTrinkets leveled lists (in higher proportion for the Powder Ganger leveled lists).

REASONING: These are the leveled lists used for clutter drops by NPCs. The changes make the Lunchbox crafting recipes (Bottlecap Mine, Caravan Lunch, Trail Mix) more viable, since Lunchboxes are uncommon in the vanilla game.

* Added Cave Fungus to FoodFresh100, FoodGenericNV75, and FoodGenericNV100 leveled lists.

REASONING: Cave Fungus was very rare in the vanilla game, mainly only being carried by Legion members. These leveled lists are used infrequently in generic loot and merchant inventories, so give some additional oppertunities to find or purchase Cave Fungus without being overpowered. The rarity of Cave Fungus in the vanilla game was likely due to it's raditation removal. Honest Hearts threw this out of the window by making the plant incredibly common, and many mods also make the fungus pickable in the Mojave too. The high fungus requirement in the pre-patch Hydra recipe (5) suggests that it was intended to be more common at one point in development.

* Breaking down clipboards at the Sink Book Chute will only produce 1 Duct Tape for every 4 Clipboards.
* Breaking down Pencils at the Sink Book Chute will no longer produce Scrap Metal. The amount of Lead has been increased from 5 to 25.
* Breaking down Coffee Mugs at Muggy will now produce 1 Empty Syringe (decreased from 3) and 1 Wonderglue (decreased from 2) for every 5 Coffee Mugs.
* Breaking down Coffee Pots at Muggy will now produce 1 Scrap Metal (decreased from 2) for every 3 Coffee Pots.
* Breaking down Dinner Plates at Muggy will now produce 1 Scrap Metal (decreased from 3) for every 5 Dinner Plates.
* Breaking down other plates at Muggy will now produce half the scrap compared to vanilla, except the White Plate, which is unchanged.
* Muggy will only produce 1 Scrap Electronics (down from 5) and 20 Energy Cells and Microfusion Cells (down from 50) per day.

REASONING: The amount of scrap produced by these routes was quite ridiculous. This makes Repair Kits very easy to craft, and further devalues normal repair routes. The adjusted scrap quantities are intended to slightly resemble the quantity of items required for the Cookery-to-Metal and Meals-to-Metal recipes.

* Decreased the loot in various generic Old World Blues containers to be more similar to similar containers in the Mojave Wasteland.

REASONING: The loot in these containers was unbalanced compared to the base game and other DLCs and provided a surplus of valuable items.

And the rest...

* Decreased the amount of Healing Powder in Legion footlockers.
* Decreased the amount of NCR Dollars and Legion Denarii found in loot, to be more equal to the number of caps in similar loot.
* Decreased the amount of alcohol items in some containers, due to the items' high values.
* Decreased the number of Bobby Pins in NVDLC01ClutterCrafting100 (clutter list used in Dead Money) from 3 to 1.
____________________________________________________________________________________________________